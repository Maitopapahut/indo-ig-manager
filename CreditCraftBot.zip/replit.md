# Telegram Instagram Credentials Bot

## Overview

This is a Telegram bot designed to manage Instagram credentials for authorized users. The bot provides a secure way to store, view, and delete Instagram account credentials through an interactive interface with inline keyboards. The system implements user authorization and maintains persistent data storage for both user permissions and credentials.

## System Architecture

The application follows a simple file-based architecture with the following key components:

- **Telegram Bot Interface**: Handles user interactions through commands and inline keyboards
- **File-Based Storage**: Uses text files for data persistence
- **Authorization System**: Validates users against an authorized users list
- **Command Processing**: Handles various bot commands and user inputs

## Key Components

### 1. Bot Core
- **Purpose**: Main bot logic and command handling
- **Technology**: Telegram Bot API integration
- **Responsibilities**: 
  - Process user commands (/start, /add, /view, /delete)
  - Handle inline keyboard interactions
  - Manage user sessions and input validation

### 2. Authentication Module
- **Purpose**: User authorization and access control
- **Data Source**: `data/users.txt` file
- **Functionality**: 
  - Verify user permissions before allowing operations
  - Block unauthorized users with appropriate messaging

### 3. Credentials Management
- **Purpose**: Store and manage Instagram credentials
- **Data Source**: `data/credentials.txt` file
- **Features**:
  - Add new credentials with automatic default password fallback
  - View all stored credentials with timestamps
  - Delete specific credentials by Instagram ID
  - Track total credential count

### 4. Activity Logging
- **Purpose**: Track bot usage and operations
- **Data Source**: `data/activity_log.txt` file
- **Functionality**: Log user activities for monitoring and debugging

## Data Flow

1. **User Authentication**: User sends command → Bot checks `users.txt` → Allow/Deny access
2. **Add Credentials**: User provides Instagram ID (+ optional password) → Bot saves to `credentials.txt` with timestamp
3. **View Credentials**: User requests view → Bot reads `credentials.txt` → Displays formatted list
4. **Delete Credentials**: User specifies Instagram ID → Bot removes entry from `credentials.txt`
5. **Activity Tracking**: All operations logged to `activity_log.txt`

## External Dependencies

- **Telegram Bot API**: For bot communication and interface
- **File System**: For persistent data storage
- **Date/Time Libraries**: For timestamp generation

## Deployment Strategy

The bot is designed for simple deployment with:
- File-based storage (no database required)
- Minimal external dependencies
- Easy configuration through text files
- Portable across different environments

## Data Structure

### Users File (`data/users.txt`)
- Contains authorized user IDs or usernames
- One entry per line

### Credentials File (`data/credentials.txt`)
- Format: Instagram ID, Password, Date Added
- Structured storage for easy parsing and management

### Activity Log (`data/activity_log.txt`)
- Tracks user operations with timestamps
- Useful for monitoring and debugging

## Security Considerations

- User authorization before any operations
- Secure storage of credentials in local files
- Activity logging for audit trails
- Default password fallback to prevent incomplete entries

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

- June 30, 2025: **Premium Bot Enhancement Complete**
  - Fixed Telegram API Markdown parsing errors
  - Upgraded UI to premium styling with professional messaging
  - Added Statistics Dashboard with real-time analytics
  - Added Settings Panel with configuration overview
  - Enhanced keyboard layout (3x2 button grid)
  - Improved all user messages with premium branding
  - Added activity monitoring and system status features
  - Implemented comprehensive help & guide system

- June 30, 2025: **Import System & Logging Enhancement Complete**
  - Fixed /import command file upload handling
  - Added comprehensive default password support for bulk imports
  - Enhanced CSV/TXT file processing with better error handling
  - Added real-time group logging system with complete activity monitoring
  - Implemented /setloggroup command for admin configuration
  - Added detailed import results with success rates and statistics
  - Enhanced file validation and processing feedback
  - Added complete database snapshots to log group after operations

## Premium Features Added

- **Statistics Dashboard**: Real-time account analytics and activity logs
- **Settings Panel**: Configuration overview and premium feature status
- **Enhanced UI**: Professional styling with premium branding
- **Improved UX**: Better button layouts and comprehensive messaging
- **Activity Monitoring**: Detailed logging and recent activity tracking
- **Premium Help System**: Comprehensive guide with pro tips

## Changelog

- June 30, 2025: Initial setup and premium enhancement implementation